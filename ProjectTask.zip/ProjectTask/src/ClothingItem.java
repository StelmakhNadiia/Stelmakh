
public class ClothingItem {
    private String clothes;
    private String color;
    private double price;


    public ClothingItem(String clothes, String color, double price) {
        this.clothes = clothes;
        this.color = color;
        this.price = price;
    }


    public String getClothes() {
        return clothes;
    }

    public String getColor() {
        return color;
    }

    public double getPrice() {
        return price;
    }


    @Override
    public String toString() {
        return clothes + ", " + color + ", " + price;
    }
}
