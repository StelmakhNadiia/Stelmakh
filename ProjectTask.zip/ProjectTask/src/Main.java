
public class Main {
    public static void main(String[] args) {
        // Запуск графічного інтерфейсу у потоці GUI
        javax.swing.SwingUtilities.invokeLater(MainFrame::new);
    }
}



