// ClothingProcessor.java
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;
public class ClothingProcessor {


    private static final String OUTPUT_DIR = "output"; // Назва папки для вихідних файлів

    // Зчитування даних з файлів у список об'єктів ClothingItem
    public static List<ClothingItem> readClothingItems(List<String> inputFiles) throws IOException {
        List<ClothingItem> items = new ArrayList<>();
        for (String file : inputFiles) {
            List<String> lines = Files.readAllLines(Paths.get(file));
            for (String line : lines) {
                if (line.trim().isEmpty() || line.startsWith("N")) continue; // Пропуск пустих рядків і заголовків
                String[] parts = line.trim().split("\\s+");
                if (parts.length >= 4) {
                    try {
                        String clothes = parts[1];
                        String color = parts[2];
                        double price = Double.parseDouble(parts[3]);
                        items.add(new ClothingItem(clothes, color, price));
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid number format: " + Arrays.toString(parts));
                    }
                }
            }
        }
        return items;
    }

    // Обробка списку об'єктів і запис у відповідні файли
    public static void process(List<ClothingItem> items, SortType sortType) throws IOException {
        Files.createDirectories(Paths.get(OUTPUT_DIR)); // Створення папки output

        // Фільтрація за ціною
        List<ClothingItem> cheap = items.stream().filter(i -> i.getPrice() <= 25.0).collect(Collectors.toList());
        List<ClothingItem> medium = items.stream().filter(i -> i.getPrice() > 25.0 && i.getPrice() <= 50.0).collect(Collectors.toList());
        List<ClothingItem> expensive = items.stream().filter(i -> i.getPrice() > 50.0).collect(Collectors.toList());

        // Сортування відповідно до вибраного типу
        sortItems(cheap, sortType);
        sortItems(medium, sortType);
        sortItems(expensive, sortType);

        // Запис у файли
        writeToFile(cheap, OUTPUT_DIR + "/cheap.txt");
        writeToFile(medium, OUTPUT_DIR + "/medium.txt");
        writeToFile(expensive, OUTPUT_DIR + "/expensive.txt");
    }

    // Метод сортування списку
    private static void sortItems(List<ClothingItem> items, SortType sortType) {
        Comparator<ClothingItem> comparator;
        switch (sortType) {
            case BY_CLOTHES_PRICE_COLOR:
                comparator = Comparator.comparing(ClothingItem::getClothes)
                        .thenComparing(ClothingItem::getPrice)
                        .thenComparing(ClothingItem::getColor);
                break;
            case BY_PRICE_CLOTHES_COLOR:
                comparator = Comparator.comparing(ClothingItem::getPrice)
                        .thenComparing(ClothingItem::getClothes)
                        .thenComparing(ClothingItem::getColor);
                break;
            case BY_COLOR_PRICE_CLOTHES:
                comparator = Comparator.comparing(ClothingItem::getColor)
                        .thenComparing(ClothingItem::getPrice)
                        .thenComparing(ClothingItem::getClothes);
                break;
            default:
                throw new IllegalArgumentException("Unexpected sort type: " + sortType);
        }
        items.sort(comparator);
    }

    // Запис списку об'єктів у файл
    private static void writeToFile(List<ClothingItem> items, String path) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(path))) {
            for (ClothingItem item : items) {
                writer.write(item.toString());
                writer.newLine();
            }
        }
    }
}
