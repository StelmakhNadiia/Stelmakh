// MainFrame.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class MainFrame extends JFrame {
    private JComboBox<String> sortTypeComboBox;

    public MainFrame() {
        // Налаштування вікна
        setTitle("Clothing Processor");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Створення випадаючого списку для вибору типу сортування
        sortTypeComboBox = new JComboBox<>(new String[]{
                "By Clothes -> Price -> Color",
                "By Price -> Clothes -> Color",
                "By Color -> Price -> Clothes"
        });

        // Створення кнопки обробки файлів
        JButton processButton = new JButton("Process Files");
        processButton.addActionListener(this::processFiles);

        // Додавання елементів у вікно
        JPanel panel = new JPanel();
        panel.add(new JLabel("Select Sort Type:"));
        panel.add(sortTypeComboBox);
        panel.add(processButton);

        add(panel, BorderLayout.CENTER);

        setVisible(true);
    }

    // Метод обробки натискання кнопки
    private void processFiles(ActionEvent event) {
        List<String> inputFiles = Arrays.asList("file1.txt", "file2.txt", "file3.txt");
        try {
            long startRead = System.nanoTime();
            List<ClothingItem> items = ClothingProcessor.readClothingItems(inputFiles);
            long endRead = System.nanoTime();

            long startProcess = System.nanoTime();
            ClothingProcessor.process(items, getSelectedSortType());
            long endProcess = System.nanoTime();

            JOptionPane.showMessageDialog(this, "Processing completed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

            System.out.println("Час зчитування файлів: " + (endRead - startRead) / 1_000_000 + " мс");
            System.out.println("Час обробки даних: " + (endProcess - startProcess) / 1_000_000 + " мс");
            System.out.println("Повний час роботи: " + (endProcess - startRead) / 1_000_000 + " мс");

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error processing files: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    // Отримання вибраного типу сортування
    private SortType getSelectedSortType() {
        switch (sortTypeComboBox.getSelectedIndex()) {
            case 0:
                return SortType.BY_CLOTHES_PRICE_COLOR;
            case 1:
                return SortType.BY_PRICE_CLOTHES_COLOR;
            case 2:
                return SortType.BY_COLOR_PRICE_CLOTHES;
            default:
                throw new IllegalStateException("Unexpected value: " + sortTypeComboBox.getSelectedIndex());
        }
    }
}
