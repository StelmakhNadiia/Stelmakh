// SortType.java
enum SortType {
    BY_CLOTHES_PRICE_COLOR, // За одягом -> ціною -> кольором
    BY_PRICE_CLOTHES_COLOR, // За ціною -> одягом -> кольором
    BY_COLOR_PRICE_CLOTHES  // За кольором -> ціною -> одягом
}
